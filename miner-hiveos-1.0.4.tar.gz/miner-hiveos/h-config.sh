#!/usr/bin/env bash

[[ -e /hive/miners/custom ]] && . /hive/miners/custom/miner-hiveos/h-manifest.conf

conf=""

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

if [[ "$conf" =~ %WORKER_NAME% ]]; then
    if [[ -f /hive-config/rig.conf ]]; then
        source /hive-config/rig.conf
        worker_name="$WORKER_NAME"
    else
        worker_name="hiveos-worker"
    fi
    conf="${conf//%WORKER_NAME%/$worker_name}"
fi

if [[ "$conf" != *"--name="* ]]; then
    if [[ -f /hive-config/rig.conf ]]; then
        source /hive-config/rig.conf
        [[ ! -z "$WORKER_NAME" ]] && conf+=" --name=$WORKER_NAME"
    fi
fi

conf=$(echo "$conf" | sed 's/^ *//')

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > $CUSTOM_CONFIG_FILENAME